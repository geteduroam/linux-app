# geteduroam Linux client

This repository contains the source code for the geteduroam Linux client. Currently WIP.

# Dependencies
- Go >= 1.18
- Make

# Building
```bash
make
```

# Running
```bash
make run
```

# Testing
```bash
make test
```

# License
BSD 3
